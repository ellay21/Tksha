<?php
class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $name;
    public $email;
    public $password;
    public $gender;
    public $lat;
    public $lng;
    public $radius_preference;
    public $profile_picture;
    public $bio;
    public $created_at;

    public function __construct($db) {
    $this->conn = $db;
    $this->radius_preference = 50; // Default value
}

public function ensureCompleteProfile() {
    if (empty($this->lat) || empty($this->lng)) {
        $this->readOne(); // Reload all data
    }
    
    if (empty($this->radius_preference)) {
        $this->radius_preference = 50;
    }
    
    return !empty($this->id) && !empty($this->gender);
}
public function validateLocation() {
    if (empty($this->lat) || empty($this->lng)) {
        return false;
    }
    
    return $this->lat >= -90 && $this->lat <= 90 && 
           $this->lng >= -180 && $this->lng <= 180;
}
    // Create new user
    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                SET
                    name = :name,
                    email = :email,
                    password = :password,
                    gender = :gender,
                    location_coords = POINT(:lat, :lng),
                    radius_preference = :radius_preference,
                    profile_picture = :profile_picture,
                    bio = :bio";

        $stmt = $this->conn->prepare($query);

        // Sanitize and bind values
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = htmlspecialchars(strip_tags($this->password));
        $this->gender = htmlspecialchars(strip_tags($this->gender));
        $this->radius_preference = htmlspecialchars(strip_tags($this->radius_preference));
        $this->profile_picture = $this->profile_picture ? htmlspecialchars(strip_tags($this->profile_picture)) : null;
        $this->bio = $this->bio ? htmlspecialchars(strip_tags($this->bio)) : null;

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        
        // Hash the password
        $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
        $stmt->bindParam(":password", $password_hash);
        
        $stmt->bindParam(":gender", $this->gender);
        $stmt->bindParam(":lat", $this->lat);
        $stmt->bindParam(":lng", $this->lng);
        $stmt->bindParam(":radius_preference", $this->radius_preference);
        $stmt->bindParam(":profile_picture", $this->profile_picture);
        $stmt->bindParam(":bio", $this->bio);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Check if email exists
    public function emailExists() {
        $query = "SELECT id, name, email, password, gender, 
                    ST_X(location_coords) as lat, 
                    ST_Y(location_coords) as lng, 
                    radius_preference, profile_picture, bio
                FROM " . $this->table_name . "
                WHERE email = ?
                LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $this->email = htmlspecialchars(strip_tags($this->email));
        $stmt->bindParam(1, $this->email);
        $stmt->execute();

        $num = $stmt->rowCount();

        if($num > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->password = $row['password'];
            $this->gender = $row['gender'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->radius_preference = $row['radius_preference'];
            $this->profile_picture = $row['profile_picture'];
            $this->bio = $row['bio'];
            
            return true;
        }

        return false;
    }

    // Get user by ID
    public function readOne() {
        $query = "SELECT id, name, email, gender, 
                    ST_X(location_coords) as lat, 
                    ST_Y(location_coords) as lng, 
                    radius_preference, profile_picture, bio, created_at
                FROM " . $this->table_name . "
                WHERE id = ?
                LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            $this->name = $row['name'];
            $this->email = $row['email'];
            $this->gender = $row['gender'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->radius_preference = $row['radius_preference'];
            $this->profile_picture = $row['profile_picture'];
            $this->bio = $row['bio'];
            $this->created_at = $row['created_at'];
            
            return true;
        }
        
        return false;
    }

    // Update user profile
    public function updateProfile() {
        $query = "UPDATE " . $this->table_name . "
                SET
                    name = :name,
                    bio = :bio
                WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize and bind values
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->bio = $this->bio ? htmlspecialchars(strip_tags($this->bio)) : null;

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":bio", $this->bio);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Update profile picture
    public function updateProfilePicture() {
        $query = "UPDATE " . $this->table_name . "
                SET
                    profile_picture = :profile_picture
                WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize and bind values
        $this->profile_picture = htmlspecialchars(strip_tags($this->profile_picture));

        $stmt->bindParam(":profile_picture", $this->profile_picture);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }
public function testDistanceCalculation($lat1, $lng1, $lat2, $lng2) {
    $query = "SELECT 
        (6371 * acos(
            cos(radians(:lat1)) 
            * cos(radians(:lat2)) 
            * cos(radians(:lng2) - radians(:lng1)) 
            + sin(radians(:lat1)) 
            * sin(radians(:lat2))
        )) as distance";
    
    $stmt = $this->conn->prepare($query);
    $stmt->execute([
        ':lat1' => $lat1,
        ':lng1' => $lng1,
        ':lat2' => $lat2,
        ':lng2' => $lng2
    ]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC)['distance'];
}
    // Get potential matches
public function getPotentialMatches() {
    // Validate current user's location first
    if (!$this->validateLocation()) {
        throw new Exception("Current user has invalid location coordinates");
    }

    $query = "SELECT u.id, u.name, u.gender, u.profile_picture, u.bio,
                ST_X(u.location_coords) as lat, 
                ST_Y(u.location_coords) as lng,
                /* Haversine formula implementation */
                (6371 * acos(
                    cos(radians(:current_lat)) 
                    * cos(radians(ST_X(u.location_coords))) 
                    * cos(radians(ST_Y(u.location_coords)) - radians(:current_lng)) 
                    + sin(radians(:current_lat)) 
                    * sin(radians(ST_X(u.location_coords)))
                )) as distance,
                COUNT(DISTINCT ua.activity_id) as shared_activities
            FROM " . $this->table_name . " u
            LEFT JOIN user_activities ua ON u.id = ua.user_id
            LEFT JOIN user_activities current_ua ON 
                current_ua.user_id = :user_id AND 
                current_ua.activity_id = ua.activity_id
            LEFT JOIN swipes s ON 
                s.swiper_id = :user_id AND 
                s.swiped_id = u.id
            WHERE u.gender != :gender
            AND u.id != :user_id
            AND s.id IS NULL
            /* Coordinate validation */
            AND ST_X(u.location_coords) BETWEEN -90 AND 90
            AND ST_Y(u.location_coords) BETWEEN -180 AND 180
            GROUP BY u.id
            HAVING distance IS NOT NULL
            AND distance <= :radius
            ORDER BY shared_activities DESC, distance ASC
            LIMIT 50";

    $stmt = $this->conn->prepare($query);
    
    $stmt->bindValue(':user_id', $this->id, PDO::PARAM_INT);
    $stmt->bindValue(':gender', $this->gender, PDO::PARAM_STR);
    $stmt->bindValue(':current_lat', $this->lat, PDO::PARAM_STR);
    $stmt->bindValue(':current_lng', $this->lng, PDO::PARAM_STR);
    $stmt->bindValue(':radius', $this->radius_preference, PDO::PARAM_INT);
    
    try {
        $stmt->execute();
        return $stmt;
    } catch (PDOException $e) {
        error_log("Matching query failed: " . $e->getMessage());
        throw new Exception("Could not process matching");
    }
}
    // Update user location
    public function updateLocation() {
        $query = "UPDATE " . $this->table_name . "
                SET location_coords = POINT(:lat, :lng)
                WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':lat', $this->lat);
        $stmt->bindParam(':lng', $this->lng);
        $stmt->bindParam(':id', $this->id);
        
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }

    // Update radius preference
    public function updateRadiusPreference() {
        $query = "UPDATE " . $this->table_name . "
                SET radius_preference = :radius_preference
                WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':radius_preference', $this->radius_preference);
        $stmt->bindParam(':id', $this->id);
        
        if($stmt->execute()) {
            return true;
        }
        
        return false;
    }
}
?>
