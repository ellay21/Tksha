<?php
// Database setup script
$host = "localhost";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS tksha";
    $conn->exec($sql);
    echo "Database created successfully<br>";
    
    // Select database
    $conn->exec("USE tksha");
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    gender ENUM('male', 'female') NOT NULL,
    location_coords POINT NOT NULL COMMENT 'Stores valid geographic coordinates',
    radius_preference INT NOT NULL DEFAULT 50 
        COMMENT 'In kilometers, must be between 1 and 1000',
    profile_picture VARCHAR(255) DEFAULT NULL,
    bio TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(location_coords),
    CONSTRAINT chk_radius CHECK (radius_preference BETWEEN 1 AND 1000)
)";
    $conn->exec($sql);
    echo "Table users created successfully<br>";
    
    // Create activities table
    $sql = "CREATE TABLE IF NOT EXISTS activities (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) UNIQUE NOT NULL
    )";
    $conn->exec($sql);
    echo "Table activities created successfully<br>";
    
    // Create user_activities table
    $sql = "CREATE TABLE IF NOT EXISTS user_activities (
        user_id INT NOT NULL,
        activity_id INT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE,
        PRIMARY KEY (user_id, activity_id)
    )";
    $conn->exec($sql);
    echo "Table user_activities created successfully<br>";
    
    // Create swipes table
    $sql = "CREATE TABLE IF NOT EXISTS swipes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        swiper_id INT NOT NULL,
        swiped_id INT NOT NULL,
        is_like BOOLEAN NOT NULL,
        swiped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (swiper_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (swiped_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "Table swipes created successfully<br>";
    
    // Create matches table
    $sql = "CREATE TABLE IF NOT EXISTS matches (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user1_id INT NOT NULL,
        user2_id INT NOT NULL,
        matched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user1_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (user2_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "Table matches created successfully<br>";
    
    // Create messages table
    $sql = "CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        match_id INT NOT NULL,
        sender_id INT NOT NULL,
        content TEXT NOT NULL,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "Table messages created successfully<br>";
    
    // Insert default activities
    $activities = [
        'Hiking', 'Cooking', 'Reading', 'Movies', 'Music', 'Dancing',
        'Photography', 'Travel', 'Fitness', 'Yoga', 'Swimming', 'Cycling',
        'Running', 'Gaming', 'Art', 'Theater', 'Concerts', 'Sports',
        'Camping', 'Fishing', 'Gardening', 'Volunteering', 'Shopping',
        'Wine Tasting', 'Coffee', 'Foodie', 'Pets', 'Technology'
    ];
    
    $stmt = $conn->prepare("INSERT IGNORE INTO activities (name) VALUES (?)");
    
    foreach($activities as $activity) {
        $stmt->bindParam(1, $activity);
        $stmt->execute();
    }
    
    echo "Default activities inserted successfully<br>";
    
    echo "Database setup completed successfully!";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
