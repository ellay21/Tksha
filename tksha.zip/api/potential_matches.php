<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include database and object files
include_once '../config/database.php';
include_once '../models/User.php';
include_once '../models/Activity.php';
include_once '../utils/jwt.php';
include_once '../utils/location.php';
// Get database connection
$database = new Database();
$db = $database->getConnection();

// Instantiate user object
$user = new User($db);
$activity = new Activity($db);

// Get JWT from headers
$headers = getallheaders();
$jwt = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

// Validate JWT
$jwt_handler = new JwtHandler();
$user_id = $jwt_handler->validateToken($jwt);

if(!$user_id) {
    // Set response code - 401 Unauthorized
    http_response_code(401);
    
    // Tell the user
    echo json_encode(array("message" => "Access denied."));
    exit;
}

// After validating JWT and setting user ID:
$user->id = $user_id;

try {
    if (!$user->ensureCompleteProfile()) {
        throw new Exception("User profile is incomplete for matching");
    }
    
    // Additional coordinate validation
    if (!LocationUtil::validateCoordinates($user->lat, $user->lng)) {
        http_response_code(400);
        echo json_encode(["message" => "Your location data is invalid"]);
        exit;
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["message" => $e->getMessage()]);
    exit;
}

// Get potential matches
$stmt = $user->getPotentialMatches();
$num = $stmt->rowCount();

if($num > 0) {
    $matches_arr = array();
    
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        // Get user activities
        $activity_stmt = $activity->getUserActivities($id);
        $activities = array();
        
        while($activity_row = $activity_stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($activities, array(
                "id" => $activity_row['id'],
                "name" => $activity_row['name']
            ));
        }
        
        $match_item = array(
            "id" => $id,
            "name" => $name,
            "gender" => $gender,
            "lat" => $lat,
            "lng" => $lng,
            "distance" => round($distance, 1),
            "shared_activities" => $shared_activities,
            "activities" => $activities
        );
        
        array_push($matches_arr, $match_item);
    }
    
    // Set response code - 200 OK
    http_response_code(200);
    
    // Show matches
    echo json_encode($matches_arr);
} else {
    // Set response code - 404 Not found
    http_response_code(404);
    
    // Tell the user no matches found
    echo json_encode(array("message" => "No potential matches found."));
}
?>
